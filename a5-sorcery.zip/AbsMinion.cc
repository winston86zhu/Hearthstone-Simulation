#include "AbsMinion.h"
#include "Player.h"

AbsMinion::AbsMinion(int cost, std::string name): Card{cost, name}{}

AbsMinion::~AbsMinion(){}

